import { Component } from '@angular/core';

@Component({
  selector: 'app-challenges',
  imports: [],
  templateUrl: './challenges.component.html',
  styleUrl: './challenges.component.css'
})
export class ChallengesComponent {

}
